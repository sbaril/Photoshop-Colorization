#target photoshop

if (documents.length == 0) {
    // alert("There are no documents open.");
}
else {
    // =======================================================
    var idsetd = charIDToTypeID( "setd" );
        var desc3 = new ActionDescriptor();
        var idnull = charIDToTypeID( "null" );
            var ref1 = new ActionReference();
            var idLyr = charIDToTypeID( "Lyr " );
            var idOrdn = charIDToTypeID( "Ordn" );
            var idTrgt = charIDToTypeID( "Trgt" );
            ref1.putEnumerated( idLyr, idOrdn, idTrgt );
        desc3.putReference( idnull, ref1 );
        var idT = charIDToTypeID( "T   " );
            var desc4 = new ActionDescriptor();
            var idlayerLocking = stringIDToTypeID( "layerLocking" );
                var desc5 = new ActionDescriptor();
                var idprotectNone = stringIDToTypeID( "protectNone" );
                desc5.putBoolean( idprotectNone, true );
            var idlayerLocking = stringIDToTypeID( "layerLocking" );
            desc4.putObject( idlayerLocking, idlayerLocking, desc5 );
        var idLyr = charIDToTypeID( "Lyr " );
        desc3.putObject( idT, idLyr, desc4 );
    executeAction( idsetd, desc3, DialogModes.NO );

}