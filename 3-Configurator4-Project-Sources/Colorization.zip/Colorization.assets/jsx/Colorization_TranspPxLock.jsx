#target photoshop

if (documents.length == 0) {
    // alert("There are no documents open.");
}
else {
    // =======================================================
    var idsetd = charIDToTypeID( "setd" );
        var desc5 = new ActionDescriptor();
        var idnull = charIDToTypeID( "null" );
            var ref3 = new ActionReference();
            var idLyr = charIDToTypeID( "Lyr " );
            var idOrdn = charIDToTypeID( "Ordn" );
            var idTrgt = charIDToTypeID( "Trgt" );
            ref3.putEnumerated( idLyr, idOrdn, idTrgt );
        desc5.putReference( idnull, ref3 );
        var idT = charIDToTypeID( "T   " );
            var desc6 = new ActionDescriptor();
            var idlayerLocking = stringIDToTypeID( "layerLocking" );
                var desc7 = new ActionDescriptor();
                var idprotectTransparency = stringIDToTypeID( "protectTransparency" );
                desc7.putBoolean( idprotectTransparency, true );
            var idlayerLocking = stringIDToTypeID( "layerLocking" );
            desc6.putObject( idlayerLocking, idlayerLocking, desc7 );
        var idLyr = charIDToTypeID( "Lyr " );
        desc5.putObject( idT, idLyr, desc6 );
    executeAction( idsetd, desc5, DialogModes.NO );

}