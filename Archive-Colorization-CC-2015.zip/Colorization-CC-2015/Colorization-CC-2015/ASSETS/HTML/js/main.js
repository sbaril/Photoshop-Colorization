/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global $, window, location, CSInterface, SystemPath, themeManager*/

(function () {
    'use strict';

    var csInterface = new CSInterface();
	var ExtensionId = "com.sbaril.colorization";
    
    // Opens the chrome developer tools in host app
    function showDevTools() {
        window.__adobe_cep__.showDevTools();
    }
    
    // Reloads extension panel
    function reloadPanel() {
        location.reload();
    }
    
    // Loads / executes a jsx file
    function loadJSXFile(pPath) {
        var scriptPath = csInterface.getSystemPath(SystemPath.EXTENSION) + pPath;
        csInterface.evalScript('evalFile("' + scriptPath + '")');
    }


    function init() {
        themeManager.init();


////////////////////////////////////////////////////////////////////////////////
// COLORIZATION BUTTONS FUNCTIONS
////////////////////////////////////////////////////////////////////////////////   
            
        $("#btn_debug").click(showDevTools);
        $("#btn_reload").click(reloadPanel);
        
        $("#btn_test").click(function () {
            csInterface.evalScript('sayHello()');
        });
        
        
        // ExtendScript Button
		/*
        $("#scriptBT").click(function () {
            loadJSXFile("/jsx/script.jsx");
        });
		*/
        
        $("#splitProofBT").click(function () {
            loadJSXFile("/jsx/Colorization_SplitProof.jsx");
        });
        
        $("#bgframesLayerBT").click(function () {
            loadJSXFile("/jsx/Colorization_SelectLayerBGFrames.jsx");
        });
        
        $("#foregroundLayerBT").click(function () {
            loadJSXFile("/jsx/Colorization_SelectLayerForeground.jsx");
        });
        
        $("#fxLayerBT").click(function () {
            loadJSXFile("/jsx/Colorization_SelectLayerFX.jsx");
        });
        
        $("#linesLayerBT").click(function () {
            loadJSXFile("/jsx/Colorization_SelectLayerLines.jsx");
        });
        
        $("#linesColorLayerBT").click(function () {
            loadJSXFile("/jsx/Colorization_SelectLayerLinesColor.jsx");
        });
        
        $("#paintBucketPresetBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_PaintBucketAll.jsx");
        });
        
        $("#brushOnePxPresetBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_BrushOnePx.jsx");
        });
        
        $("#magicWandAllPresetBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_MagicWandAll.jsx");
		});
        
        $("#colorPickerBT").click(function () {
            loadJSXFile("/jsx/Colorization_ColorPicker.jsx");
		});
        
        $("#lockTranspPxBT").click(function () {
            loadJSXFile("/jsx/Colorization_TranspPxLock.jsx");
        });
        
        $("#unlockTranspPxBT").click(function () {
            loadJSXFile("/jsx/Colorization_TranspPxUnlock.jsx");
        });
        
        $("#actionCustomOneBT").click(function () {
            loadJSXFile("/jsx/Colorization_ActionCustomOne.jsx");
        });
        
        $("#actionCustomTwoBT").click(function () {
            loadJSXFile("/jsx/Colorization_ActionCustomTwo.jsx");
        });
        
        $("#actionCustomThreeBT").click(function () {
            loadJSXFile("/jsx/Colorization_ActionCustomThree.jsx");
        });
        
        $("#actionCustomFourBT").click(function () {
            loadJSXFile("/jsx/Colorization_ActionCustomFour.jsx");
        });
        
        $("#actionCustomFiveBT").click(function () {
            loadJSXFile("/jsx/Colorization_ActionCustomFive.jsx");
        });


		/////////////////////////////////////////////////////////////////////////

        // Main Feature Button
        /*
		$("#mainBT").click(function () {
            invokeFeature("Main");
        });
		*/
        
        $("#lassoToolBT").click(function () {
            invokeFeature("Tool-Lasso_Tool");
        });




		
////////////////////////////////////////////////////////////////////////////////
// COLORIZATION FLYOUT MENU
////////////////////////////////////////////////////////////////////////////////
		
		// Ugly workaround to keep track of "checked" and "enabled" statuses
		var checkableMenuItem_isChecked = true;
		var targetMenuItem_isEnabled = true;
				
		// Flyout menu XML string 
		var flyoutXML = '<Menu> \
							<MenuItem Id="AboutItemColo" Label="About Colorization"/> \
							<MenuItem Id="OpenWebsiteColo" Label="Colorization Online Infos"/> \
							\
							<MenuItem Label="---" /> \
							\
						</Menu>';

		// Uses the XML string to build the menu
		csInterface.setPanelFlyoutMenu(flyoutXML);

		// Flyout Menu Click Callback
		function flyoutMenuClickedHandler (event) {

			// the event's "data" attribute is an object, which contains "menuId" and "menuName"
			console.dir(event); 
			switch (event.data.menuId) {	
				case "AboutItemColo":
					csInterface.evalScript("alert('Colorization \\nVersion 1.0.1\\n©2015 Stephane Baril\\nhttp://sbaril.flavors.me');");
					break;
				case "OpenWebsiteColo":
					csInterface.openURLInDefaultBrowser("http://sbaril.me/#comic-books-colorisation-colorization"); LoseFocus();
					break;
				default: 
					console.log(event.data.menuName + " clicked!");
			}
		}

		// Listen for the Flyout menu clicks
		csInterface.addEventListener("com.adobe.csxs.events.flyoutMenuClicked", flyoutMenuClickedHandler);

        
        
    }  
    init();

}());
    
