/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global $, window, location, CSInterface, SystemPath, themeManager*/

(function () {
    'use strict';

    var csInterface = new CSInterface();
    
    // Opens the chrome developer tools in host app
    function showDevTools() {
        window.__adobe_cep__.showDevTools();
    }
    
    // Reloads extension panel
    function reloadPanel() {
        location.reload();
    }
    
    // Loads / executes a jsx file
    function loadJSXFile(pPath) {
        var scriptPath = csInterface.getSystemPath(SystemPath.EXTENSION) + pPath;
        csInterface.evalScript('evalFile("' + scriptPath + '")');
    }

    
    
    function init() {
        themeManager.init();


////////////////////////////////////////////////////////////////////////////////
// COLORIZSTACK BUTTONS FUNCTIONS
////////////////////////////////////////////////////////////////////////////////   
            
        $("#btn_debug").click(showDevTools);
        $("#btn_reload").click(reloadPanel);
        
        $("#btn_test").click(function () {
            csInterface.evalScript('sayHello()');
        });
        
        
        // ExtendScript Button
		/*
        $("#scriptBT").click(function () {
            loadJSXFile("/jsx/script.jsx");
        });
		*/
        
        $("#buildStructureBT").click(function () {
            loadJSXFile("/jsx/ColorizStack_BuildStructure.jsx");
        });
        
        $("#buildStructureSpotBT").click(function () {
            loadJSXFile("/jsx/ColorizStack_BuildStructureSpot.jsx");
        });
        
        $("#buildBendayOneBT").click(function () {
            loadJSXFile("/jsx/ColorizStack_BuildBendayOne.jsx");
        });
        
        $("#buildBendayTwoBT").click(function () {
            loadJSXFile("/jsx/ColorizStack_BuildBendayTwo.jsx");
        });
        
        $("#bgframesLayerBT").click(function () {
            loadJSXFile("/jsx/Colorization_SelectLayerBGFrames.jsx");
        });
        
        $("#foregroundLayerBT").click(function () {
            loadJSXFile("/jsx/Colorization_SelectLayerForeground.jsx");
        });
        
        $("#paintBucketPresetBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_PaintBucketAll.jsx");
        });
        
        $("#brushOnePxPresetBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_BrushOnePx.jsx");
        });
        
        $("#magicWandAllPresetBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_MagicWandAll.jsx");
        });
        
        $("#inverseBT").click(function () {
            loadJSXFile("/jsx/ColorizStack_Inverse.jsx");
        });
        
        $("#expandOnePxBT").click(function () {
            loadJSXFile("/jsx/ColorizStack_ExpandOnePx.jsx");
        });
        
        $("#contractOnePxBT").click(function () {
            loadJSXFile("/jsx/ColorizStack_ContractOnePx.jsx");
        });
        
        $("#fillForgroundColorBT").click(function () {
            loadJSXFile("/jsx/ColorizStack_FillForgroundColor.jsx");
        });
        
        $("#colorPickerBT").click(function () {
            loadJSXFile("/jsx/ColorizStack_ColorPicker.jsx");
        });
        
        $("#deselectBT").click(function () {
            loadJSXFile("/jsx/ColorizStack_Deselect.jsx");
        });
        
        $("#selectExpandFillOneBT").click(function () {
            loadJSXFile("/jsx/ColorizStack_FillExpandOnePx.jsx");
        });
        
        $("#selectExpandFillTwoBT").click(function () {
            loadJSXFile("/jsx/ColorizStack_FillExpandTwoPx.jsx");
        });
        
        $("#lockTranspPxBT").click(function () {
            loadJSXFile("/jsx/Colorization_TranspPxLock.jsx");
        });
        
        $("#unlockTranspPxBT").click(function () {
            loadJSXFile("/jsx/Colorization_TranspPxUnlock.jsx");
        });


		///////////////////////////////////////////////////////////////////////

        // Main Feature Button
        /*
		$("#mainBT").click(function () {
            invokeFeature("Main");
        });
		*/
        
        $("#lassoToolBT").click(function () {
            invokeFeature("Tool-Lasso_Tool");
        });



		
////////////////////////////////////////////////////////////////////////////////
// COLORIZSTACK FLYOUT MENU
////////////////////////////////////////////////////////////////////////////////
		
		// Ugly workaround to keep track of "checked" and "enabled" statuses
		var checkableMenuItem_isChecked = true;
		var targetMenuItem_isEnabled = true;
				
		// Flyout menu XML string 
		var flyoutXML = '<Menu> \
							<MenuItem Id="AboutItemCStack" Label="About ColorizStack"/> \
							<MenuItem Id="OpenWebsiteCStack" Label="Colorization-ColorizStack Online Infos"/> \
							\
							<MenuItem Label="---" /> \
							\
						</Menu>';

		// Uses the XML string to build the menu
		csInterface.setPanelFlyoutMenu(flyoutXML);

		// Flyout Menu Click Callback
		function flyoutMenuClickedHandler (event) {

			// the event's "data" attribute is an object, which contains "menuId" and "menuName"
			console.dir(event); 
			switch (event.data.menuId) {	
				case "AboutItemCStack":
					csInterface.evalScript("alert('ColorizStack \\nVersion 1.0.1\\nPart of Colorization 3 panels set\\n©2015 Stephane Baril\\nhttp://sbaril.flavors.me');");
					break;
				case "OpenWebsiteCStack":
					csInterface.openURLInDefaultBrowser("http://sbaril.me/#comic-books-colorisation-colorization"); LoseFocus();
					break;
				default: 
					console.log(event.data.menuName + " clicked!");
			}
		}

		// Listen for the Flyout menu clicks
		csInterface.addEventListener("com.adobe.csxs.events.flyoutMenuClicked", flyoutMenuClickedHandler);

        
        
        
    }
    init();

}());
    
