/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global $, window, location, CSInterface, SystemPath, themeManager*/

(function () {
    'use strict';

    var csInterface = new CSInterface();
    
    // Opens the chrome developer tools in host app
    function showDevTools() {
        window.__adobe_cep__.showDevTools();
    }
    
    // Reloads extension panel
    function reloadPanel() {
        location.reload();
    }
    
    // Loads / executes a jsx file
    function loadJSXFile(pPath) {
        var scriptPath = csInterface.getSystemPath(SystemPath.EXTENSION) + pPath;
        csInterface.evalScript('evalFile("' + scriptPath + '")');
    }

    /*function LoseFocus() {  
	   var csEvent = new CSEvent("com.adobe.PhotoshopLoseFocus", "APPLICATION");  
	   csEvent.extensionId = gExtensionId; // your extension's id, like com.example.helloworld  
	   csInterface.dispatchEvent(csEvent); // csInterface is a new CSInterface()  
	} */
    
    function init() {
        themeManager.init();


////////////////////////////////////////////////////////////////////////////////
// COLORIZCLEAN BUTTONS FUNCTIONS
////////////////////////////////////////////////////////////////////////////////   
            
        $("#btn_debug").click(showDevTools);
        $("#btn_reload").click(reloadPanel);
        
        $("#btn_test").click(function () {
            csInterface.evalScript('sayHello()');
        });
        
        $("#viewSideBT").click(function () {
            loadJSXFile("/jsx/ColorizClean_TwoViews.jsx");
        });
        
        $("#actualPixelsBT").click(function () {
            loadJSXFile("/jsx/ColorizClean_ViewOneOne.jsx");
        });
        
        $("#fitScreenBT").click(function () {
            loadJSXFile("/jsx/ColorizClean_ViewFitScreen.jsx");
        });
        
        $("#lightenLineBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_LightenLine.jsx");
        });
        
        $("#darkenLineBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_DarkenLine.jsx");
        });
        
        $("#dupliTranfBT").click(function () {
            loadJSXFile("/jsx/ColorizClean_DuplicateTransform.jsx");
        });
        
        $("#cropBleedIncluedBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_CropBleedIncluded.jsx");
        });
        
        $("#cropBleedExcluedBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_CropBleedExcluded.jsx");
        });
        
        $("#addBleedBT").click(function () {
            loadJSXFile("/jsx/ColorizClean_AddBleed.jsx");
        });
        
        $("#addGuideBT").click(function () {
            loadJSXFile("/jsx/ColorizClean_CreateBleedGuide.jsx");
        });
        
        $("#cloneSourceBT").click(function () {
            loadJSXFile("/jsx/ColorizClean_ShowCloneSource.jsx");
        });
        
        $("#dodgePresetBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_LightenLine.jsx");
        });
        
        $("#burnPresetBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_DarkenLine.jsx");
        });
        
        $("#cropBleedExcludedBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_CropBleedExcluded.jsx");
        });
        
        $("#cropBleedIncludedBT").click(function () {
            loadJSXFile("/jsx/ColorizTools_CropBleedIncluded.jsx");
        });


		/////////////////////////////////////////////////////////////////////

        
        $("#curvesBT").click(function () {
            invokeFeature("Main-Image-Adjustments-Curves");
        });
        
        $("#levelsBT").click(function () {
            invokeFeature("Main-Image-Adjustments-Levels");
        });
        
        $("#dodgeToolBT").click(function () {
            invokeFeature("Tool-Dodge_Tool");
			//LoseFocus();
        });
        
        $("#burnToolBT").click(function () {
            invokeFeature("Tool-Burn_Tool");
        });
        
        $("#saveBT").click(function () {
            invokeFeature("Main-File-Save");
        });
        
        $("#saveAsBT").click(function () {
            invokeFeature("Main-File-Save_As");
        });
        
        $("#rulerToolBT").click(function () {
            invokeFeature("Tool-Ruler_Tool");
        });
        
        $("#stampToolBT").click(function () {
            invokeFeature("Tool-Clone_Stamp_Tool");
        });
        
        $("#lassoToolBT").click(function () {
            invokeFeature("Tool-Lasso_Tool");
        });
        
        $("#arbitraryBT").click(function () {
            invokeFeature("Main-Image-Image_Rotation-Arbitrary");
        });



		
////////////////////////////////////////////////////////////////////////////////
// COLORIZCLEAN FLYOUT MENU
////////////////////////////////////////////////////////////////////////////////
		
		// Ugly workaround to keep track of "checked" and "enabled" statuses
		var checkableMenuItem_isChecked = true;
		var targetMenuItem_isEnabled = true;
				
		// Flyout menu XML string 
		var flyoutXML = '<Menu> \
							<MenuItem Id="AboutItemCClean" Label="About ColorizClean"/> \
							<MenuItem Id="OpenWebsiteCClean" Label="Colorization-ColorizClean Online Infos"/> \
							\
							<MenuItem Label="---" /> \
							\
						</Menu>';

		// Uses the XML string to build the menu
		csInterface.setPanelFlyoutMenu(flyoutXML);

		// Flyout Menu Click Callback
		function flyoutMenuClickedHandler (event) {

			// the event's "data" attribute is an object, which contains "menuId" and "menuName"
			console.dir(event); 
			switch (event.data.menuId) {	
				case "AboutItemCClean":
					csInterface.evalScript("alert('ColorizClean \\nVersion 1.0.1\\nPart of Colorization 3 panels set\\n©2015 Stephane Baril\\nhttp://sbaril.flavors.me');");
					break;
				case "OpenWebsiteCClean":
					csInterface.openURLInDefaultBrowser("hhttp://sbaril.me/#comic-books-colorisation-colorization"); LoseFocus();
					break;
				default: 
					console.log(event.data.menuName + " clicked!");
			}
		}

		// Listen for the Flyout menu clicks
		csInterface.addEventListener("com.adobe.csxs.events.flyoutMenuClicked", flyoutMenuClickedHandler);

        
        
        
    }   
    init();

}());
    
