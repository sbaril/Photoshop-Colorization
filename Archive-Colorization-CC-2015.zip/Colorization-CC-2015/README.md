Thank you for downloading Colorization! 

I hope it saves you a bunch of time. 


# How to install

Colorization requires Photoshop CC 2014, 2015 and 2015.5.

* If you have that then open it up and go to **File → Scripts → Browse... and select the installer.jsx** file in the same folder as these instructions. 

"Colorization" is in fact 3 subpanels (ColorizClean, ColorizStack & Colorization), so you need to do the previous instruction for the 3 sub-panels!



## *Manual install* ##

You need to install by yourself the Tools "**Colorization.tpl**" in the Presets folder. 

* **Mac:** Applications/Adobe Photoshop CC 2015.5 *(2014 or 2015)*/Presets/Tools/
* **Win:** C:\Program Files\Adobe\Adobe Photoshop CC 2015.5 *(2014 or 2015)*\Presets\Tools\

Then, after the Photoshop restart, load it by selecting "Colorization" the Tool presets panel flyout menu.

---

You need to install by yourself the Actions "**Colorization.atn**" in the Presets folder. 

* **Mac:** Applications/Adobe Photoshop CC 2015.5 *(2014 or 2015)*/Presets/Actions/
* **Win:** C:\Program Files\Adobe\Adobe Photoshop CC 2015.5 *(2014 or 2015)*\Presets\Actions\

Then, after the Photoshop restart, load it by selecting "Colorization" the Tool presets panel flyout menu.

---

You need to install by yourself the "**Colorization_Scripts**" folder in the Scripts folder.

* **Mac:** Applications/Adobe Photoshop CC 2015.5 *(2014 or 2015)*/Presets/Scripts/
* **Win:** C:\Program Files\Adobe\Adobe Photoshop CC 2015.5 *(2014 or 2015)*\Presets\Scripts\

---


# How Colorization works

This panel is designed for Photoshop CC 2015.5 *(2014 or 2015)*. It allows you to more quickly colorize Comic Books.

* Video overview: https://vimeo.com/album/1800688 
* More info on my Colorization Panels: http://sbaril.me/#comic-books-colorisation-colorization

---


# License

The Colorization Photoshop extension is created by Stéphane Baril.

It's completely free to use and to share!

###### And please, show me what you do with it ;) 


* Email: colorisation@gmail.com
* Twitter: https://twitter.com/sbaril